Student 1:
Name: Yug Bhatia
Roll number: 2025580
E-mail: yug25580@iiitd.ac.in

Student 2:
Name: Shivansh Mujoo
Roll No: 2025476
E-mail: shivansh25476@iiitd.ac.in

AI usage:
Gemini chat link: https://share.gemini.google/RexBgUYLaHSo