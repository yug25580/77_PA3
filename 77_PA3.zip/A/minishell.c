#include <errno.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>

#define MAX_LINE 1024
#define MAX_ARGS 64

static int parse_command(char *line, char *args[])
{
    int argc = 0;
    char *token = strtok(line, " \t\r\n");

    while (token != NULL && argc < MAX_ARGS - 1) {
        args[argc++] = token;
        token = strtok(NULL, " \t\r\n");
    }

    args[argc] = NULL;
    return argc;
}


static void execute_external(char *args[])
{
    fflush(stdout); //flushing first prevents text being printed twice

    pid_t pid = fork(); // create shell copy

    if (pid < 0) { //checks whether fork fails or not
        perror("fork"); //print why fork failed
        return;
    }

    if (pid == 0) { //everything inside runs only in the child
        
        execvp(args[0], args); //replaces its own memory image with the program named in args[0], thus, ls works

        fprintf(stderr, "msh: %s: %s\n", args[0], strerror(errno)); //prints when execvp fails
        _exit(127); //exits the child only
    }

    int status = 0; 
    pid_t w;

    do {
        w = waitpid(pid, &status, 0); //blocks until that specific child ends, and it reaps the child so it doesn’t become a zombie
    } while (w < 0 && errno == EINTR);

    if (w < 0) {
        perror("waitpid"); //Any other waitpid error is reported with perror, and the function returns while the shell stays alive
        return;
    }

    if (WIFSIGNALED(status)) { //true if the child was killed by a signal
        
        fprintf(stderr, "msh: process %d terminated by signal %d\n", (int)pid, WTERMSIG(status)); //gives the signal number, and the shell prints it
    }
}

int main(void)
{
    char line[MAX_LINE];
    char *args[MAX_ARGS];

    while (1) {
        printf("msh> ");
        fflush(stdout);

        if (fgets(line, sizeof(line), stdin) == NULL) {
            putchar('\n');
            break;
        }

        int argc = parse_command(line, args);
        if (argc == 0) {
            continue;
        }

        if (strcmp(args[0], "exit") == 0) {
            exit(EXIT_SUCCESS); //ends the shell immediately
        }

        if (strcmp(args[0], "cd") == 0) {
            
            if (argc != 2) { //prints error when argc is less than 1
                
                fprintf(stderr, "usage: cd <directory>\n"); 
            } else if (chdir(args[1]) != 0) {
                
                perror("cd"); //error f shell's own working dir cant be changed
            }
            continue;
        }

        execute_external(args);
    }

    return 0;
}
