#include "job_queue.h"

#include <errno.h>
#include <limits.h>
#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

#define NUM_PRINTERS 4
#define DEFAULT_JOBS 50

typedef struct {
    int id;
    job_queue_t *queue;
    long jobs_completed;
} worker_arg_t;

static void simulate_printing(void)
{
    struct timespec ts = {.tv_sec = 0, .tv_nsec = 1000000L}; /* 1 ms */
    (void)nanosleep(&ts, NULL);
}

static void *printer_worker(void *arg)
{
    worker_arg_t *w = (worker_arg_t *)arg;
    int job = 0;

    while (queue_pop(w->queue, &job)) {
        simulate_printing();
        w->jobs_completed++;       
        printf("PROCESSED job=%d printer=%d\n", job, w->id);
        fflush(stdout);
    }

    return NULL;
}

static long parse_positive_long(const char *s, const char *name)
{
    char *end = NULL;
    errno = 0;
    long value = strtol(s, &end, 10);
    if (errno != 0 || end == s || *end != '\0' || value <= 0) {
        fprintf(stderr, "Invalid %s: %s\n", name, s);
        exit(EXIT_FAILURE);
    }
    return value;
}

static int start_printers(job_queue_t *queue, pthread_t printers[],
                          worker_arg_t workers[])
{
    int created = 0;

    for (int i = 0; i < NUM_PRINTERS; i++) {
        workers[i].id = i;
        workers[i].queue = queue;
        workers[i].jobs_completed = 0;

        int rc = pthread_create(&printers[i], NULL, printer_worker, &workers[i]);
        if (rc != 0) {
            fprintf(stderr, "pthread_create (printer %d): %s\n", i, strerror(rc));
            break;
        }
        created++;
    }
    return created;
}

static int join_printers(pthread_t printers[], int created)
{
    int failed = 0;

    for (int i = 0; i < created; i++) {
        int rc = pthread_join(printers[i], NULL);
        if (rc != 0) {
            fprintf(stderr, "pthread_join (printer %d): %s\n", i, strerror(rc));
            failed = 1;               /* keep joining the rest */
        }
    }
    return failed;
}

static int run_core_server(long num_jobs)
{
    job_queue_t queue;
    pthread_t printers[NUM_PRINTERS];
    worker_arg_t workers[NUM_PRINTERS] = {0};

    if (num_jobs > INT_MAX) {
        fprintf(stderr, "Job count too large (max %d)\n", INT_MAX);
        return EXIT_FAILURE;
    }

    if (queue_init(&queue) != 0) {
        fprintf(stderr, "queue_init failed\n");
        return EXIT_FAILURE;
    }

    int created = start_printers(&queue, printers, workers); //starts printers
    if (created != NUM_PRINTERS) { //shutdown the queue, joins printers and destroys queue if only some threads start
        
        queue_shutdown(&queue);
        join_printers(printers, created);
        queue_destroy(&queue);
        return EXIT_FAILURE;
    }

    for (long job = 1; job <= num_jobs; job++) {
        
        if (queue_push(&queue, (int)job) != 0) { //blocks when the queue is full
            fprintf(stderr, "Failed to submit job %ld\n", job);
            
            queue_shutdown(&queue); //shuts down, joins printers and destroys queue on failure
            join_printers(printers, created);
            queue_destroy(&queue);
            return EXIT_FAILURE;
        }
        printf("SUBMITTED job=%ld\n", job);
        fflush(stdout);
    }

    queue_shutdown(&queue); //called only after last job is accepted

    int join_failed = join_printers(printers, created); //join_printers waits until every printer exits so that all o/p is written and the counters are final

    long total = 0;
    
    for (int i = 0; i < NUM_PRINTERS; i++) {
        total += workers[i].jobs_completed; //safe to sum without locks: every writer thread has been joined
    }

    printf("TOTAL_COMPLETED %ld\n", total);
    fflush(stdout);

    queue_destroy(&queue); //destroys the queue
    return (!join_failed && total == num_jobs) ? EXIT_SUCCESS : EXIT_FAILURE; //return success if only joins success
}

typedef struct {
    int id; //producer id
    long jobs_to_submit;
    job_queue_t *queue; //the same queue shared by all producers
    long accepted; //jobs accepted by queue_push
} producer_arg_t;

static void *producer_worker(void *arg)
{
    producer_arg_t *p = (producer_arg_t *)arg;

    for (long k = 1; k <= p->jobs_to_submit; k++) {
        int job = (int)((long)p->id * p->jobs_to_submit + k); //gives producer 0 the ids 1...k, producer 1 ids 1...2k

        if (queue_push(p->queue, job) != 0) {//if accepted < jobs_to_submit then main reports failure
            fprintf(stderr, "producer %d: failed to submit job %d\n", p->id, job);
            break;                     
        }
        p->accepted++; //counts the accepted job in this thread’s private counter

        //printf locks the file, so that each line is printed atomically
        printf("SUBMITTED producer=%d job=%d\n", p->id, job);
        fflush(stdout);
    }
    return NULL;
}

static int run_bonus_server(long producers, long jobs_per_producer)
{
    job_queue_t queue; 
    pthread_t printers[NUM_PRINTERS]; //declare printers
    worker_arg_t workers[NUM_PRINTERS] = {0}; //declare workers
    int ok = 1;

    if (producers > INT_MAX / jobs_per_producer) { //reject a total no of jobs that would overflow int
        fprintf(stderr, "Too many jobs requested (max total %d)\n", INT_MAX);
        return EXIT_FAILURE;
    }
    long expected_total = producers * jobs_per_producer; //no of jobs that must complete

    producer_arg_t *pargs = calloc((size_t)producers, sizeof(*pargs)); //allocate producer args using calloc
    pthread_t *pthreads = calloc((size_t)producers, sizeof(*pthreads));//allocate producer threads using calloc

    if (pargs == NULL || pthreads == NULL) { //free memory if args or threads is NULL
        fprintf(stderr, "out of memory\n");
        free(pargs);
        free(pthreads);
        return EXIT_FAILURE;
    }

    if (queue_init(&queue) != 0) { //initializes queue and frees memory on failure
        fprintf(stderr, "queue_init failed\n");
        free(pargs);
        free(pthreads);
        return EXIT_FAILURE;
    }

    int printers_created = start_printers(&queue, printers, workers); //starts printers

    if (printers_created != NUM_PRINTERS) { //cleans up on partial failure and returns
        queue_shutdown(&queue);
        join_printers(printers, printers_created);
        queue_destroy(&queue);
        free(pargs);
        free(pthreads);
        return EXIT_FAILURE;
    }

    long producers_created = 0;

    for (long i = 0; i < producers; i++) {
        pargs[i].id = (int)i;
        pargs[i].jobs_to_submit = jobs_per_producer;
        pargs[i].queue = &queue;
        pargs[i].accepted = 0;

        int rc = pthread_create(&pthreads[i], NULL, producer_worker, &pargs[i]); //creating one thread per producer

        if (rc != 0) {//when creation fails, break
            fprintf(stderr, "pthread_create (producer %ld): %s\n", i, strerror(rc));
            ok = 0;
            break;       /* still must join the producers that did start */
        }
        producers_created++; //counts started ones
    }

    for (long i = 0; i < producers_created; i++) {
        int rc = pthread_join(pthreads[i], NULL); //join all producers first

        if (rc != 0) {
            fprintf(stderr, "pthread_join (producer %ld): %s\n", i, strerror(rc));
            ok = 0;
        }
        if (pargs[i].accepted != jobs_per_producer) {//checks that each producer submitted its full data, otherwise ok = 0
            ok = 0;      /* a producer failed to submit its full quota */
        }
    }

    queue_shutdown(&queue); //shutdown after every process finishes

    if (join_printers(printers, printers_created) != 0) { //joins all the printers and drain the remaining jobs
        ok = 0;
    }

    long total = 0;

    for (int i = 0; i < NUM_PRINTERS; i++) { //sum the counters
        total += workers[i].jobs_completed;
    }

    printf("TOTAL_COMPLETED %ld\n", total);
    fflush(stdout);

    //destroy queue and free the heap mem
    queue_destroy(&queue); 
    free(pargs);
    free(pthreads);

    return (ok && total == expected_total) ? EXIT_SUCCESS : EXIT_FAILURE; //returns success if required condition is met
}

int main(int argc, char *argv[])
{
    if (argc >= 2 && strcmp(argv[1], "--bonus") == 0) {
        if (argc != 4) {
            fprintf(stderr, "Usage: %s --bonus <producers> <jobs-per-producer>\n", argv[0]);
            return EXIT_FAILURE;
        }
        long producers = parse_positive_long(argv[2], "producer count");
        long jobs = parse_positive_long(argv[3], "jobs per producer");
        return run_bonus_server(producers, jobs);
    }

    if (argc > 2) {
        fprintf(stderr, "Usage: %s [number-of-jobs]\n", argv[0]);
        return EXIT_FAILURE;
    }

    long num_jobs = (argc == 2) ? parse_positive_long(argv[1], "job count") : DEFAULT_JOBS;
    return run_core_server(num_jobs);
}
