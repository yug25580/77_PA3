#include "job_queue.h"

#include <stddef.h>

int queue_init(job_queue_t *q)
{
    if (q == NULL) {
        return -1;
    }

    q->head = 0;
    q->tail = 0;
    q->count = 0;
    q->shutdown = 0;

    if (pthread_mutex_init(&q->mutex, NULL) != 0) { //initialize mutex
        return -1;
    }

    if (pthread_cond_init(&q->not_empty, NULL) != 0) { //initializ not_empty
        pthread_mutex_destroy(&q->mutex); //destroys mutex on failure, so leakage doesnt happen
        return -1;
    }

    if (pthread_cond_init(&q->not_full, NULL) != 0) { //initialize not_full
        pthread_cond_destroy(&q->not_empty);
        pthread_mutex_destroy(&q->mutex); //destroy both on failure
        return -1;
    }

    return 0;
}

void queue_destroy(job_queue_t *q)
{
    if (q == NULL) {
        return;
    }

    pthread_cond_destroy(&q->not_full);
    pthread_cond_destroy(&q->not_empty);
    pthread_mutex_destroy(&q->mutex);
}

int queue_push(job_queue_t *q, int job)
{
    if (q == NULL) {
        return -1;
    }

    if (pthread_mutex_lock(&q->mutex) != 0) { //locks the mutex
        return -1;
    }

    while (q->count == QUEUE_CAPACITY && !q->shutdown) {
        if (pthread_cond_wait(&q->not_full, &q->mutex) != 0) {//release mutex automatically and sleeps
            pthread_mutex_unlock(&q->mutex); //unlocks mutex
            return -1;
        }
    }

    if (q->shutdown) { //when shutdown is requested
        pthread_mutex_unlock(&q->mutex); //unlock mutex
        return -1;
    }

    q->jobs[q->tail] = job; //insert at tail
    q->tail = (q->tail + 1) % QUEUE_CAPACITY; //advancing the tail circularly
    q->count++; //update count

    pthread_cond_signal(&q->not_empty); 

    if (pthread_mutex_unlock(&q->mutex) != 0) {
        return -1;
    }
    return 0;
}

int queue_pop(job_queue_t *q, int *job)
{
    if (q == NULL || job == NULL) {
        return 0;
    }

    //locks the mutex
    if (pthread_mutex_lock(&q->mutex) != 0) { 
        return 0;
    }

    while (q->count == 0 && !q->shutdown) {

        if (pthread_cond_wait(&q->not_empty, &q->mutex) != 0) { //wait on non_empty
            pthread_mutex_unlock(&q->mutex);
            return 0;
        }
    }

    if (q->count == 0) {
        pthread_mutex_unlock(&q->mutex); //unlock mutex when count is 0
        return 0;
    }

    // remove the oldest job at head and advance head circularly
    *job = q->jobs[q->head];
    q->head = (q->head + 1) % QUEUE_CAPACITY;
    q->count--;

    pthread_cond_signal(&q->not_full); //wakes one producer blocked on a full queue

    if (pthread_mutex_unlock(&q->mutex) != 0) {
        return 0;
    }
    return 1;
}

void queue_shutdown(job_queue_t *q)
{
    if (q == NULL) {
        return;
    }

    pthread_mutex_lock(&q->mutex); //lock mutex
    q->shutdown = 1;

    pthread_cond_broadcast(&q->not_empty); //waking all sleeping consumers so each sees empty and shutdown and exits
    pthread_cond_broadcast(&q->not_full); //a producer blocked on a full queue also wakes and gets -1

    pthread_mutex_unlock(&q->mutex);
}
